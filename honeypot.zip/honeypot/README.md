# 🍯 HoneyShield - Cyber Attack Detection System

![Python](https://img.shields.io/badge/Python-3.11+-blue.svg)
![FastAPI](https://img.shields.io/badge/FastAPI-0.103+-009688.svg)
![Docker](https://img.shields.io/badge/Docker-Ready-2496ED.svg)

HoneyShield is an advanced, honeypot-based cyber attack detection system that mimics vulnerable services to capture, log, and analyze malicious traffic. It provides a real-time dashboard for SOC analysts, complete with global threat mapping and automated attack classification using machine learning.

The system captures connection attempts and payload data, enriching it with GeoIP information before streaming it to a beautiful, cyberpunk-themed frontend via WebSockets. An embedded Machine Learning pipeline automatically classifies attacks based on behavioral features.

## Architecture
```text
  [ Attackers ]
       | (Internet)
       v
 +-----+-----+-----+-----+
 | SSH | HTTP| FTP |Telnt| (Honeypot Services)
 +-----+-----+-----+-----+
       |
       v
 [ Backend Orchestrator ] -> GeoIP Lookup
       |
       +--> [ ML Classifier (RandomForest) ]
       |
       v
 [ SQLite DB / Event Logs ]
       |
       v
 [ FastAPI API & WebSocket ] -> [ Frontend Dashboard ]
```

## Features
- 🚨 **Multi-Service Honeypots**: Simulates SSH, HTTP, FTP, and Telnet vulnerabilities.
- 🌐 **Global Threat Map**: Real-time Leaflet map showing attacker origin via GeoIP.
- 🤖 **ML Classification**: Uses Random Forest to classify attack types (brute-force, botnet, etc.).
- ⚡ **Real-Time WebSocket Feed**: Live attack streaming directly to the browser.
- 📊 **Rich Analytics**: Visualizations via Chart.js (Donut, Bar, Timeline).
- 🐳 **Docker Ready**: Deploy everything with a single `docker-compose` command.

## Quick Start

### Option A: Run Locally
1. Clone the repository and install requirements:
   ```bash
   pip install -r requirements.txt
   ```
2. Start the backend orchestrator:
   ```bash
   python backend/orchestrator.py
   ```

### Option B: Run via Docker (Recommended)
```bash
docker compose up -d
```

## Dashboard
Access the beautiful, dark-themed frontend at:  
**http://localhost:5000**

## Honeypot Ports

| Service | Port | Description |
|---------|------|-------------|
| SSH     | 2222 | Fake SSH server logging credentials |
| HTTP    | 8080 | Fake web server logging payloads |
| FTP     | 2121 | Fake FTP server |
| Telnet  | 2323 | Fake IoT device prompt |

## Demo Simulation
Need to showcase the dashboard without putting it on the public internet? Run the simulation script to generate realistic synthetic attacks:
```bash
python demo_simulation.py --count 100
```

## ML Training
To generate a new synthetic dataset and train the Machine Learning model:
```bash
cd ml
python generate_dataset.py
python train.py
```

## Alerting Configuration
(Guide coming soon. Webhook integration for Slack/Discord alerts.)

## Screenshots
*(Insert screenshots of the HoneyShield SOC Dashboard here)*

## Academic / Concepts Demonstrated
- **Intrusion Detection**: Mimicking high-interaction and low-interaction honeypots.
- **Data Engineering**: Real-time event streaming and GeoIP enrichment.
- **Machine Learning**: Supervised classification of network behaviors.
- **Frontend Development**: Interactive WebSocket-based UI design.
