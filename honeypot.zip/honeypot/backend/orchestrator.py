import sys
import os
import threading
import time
import uvicorn

# ── Path setup: must run from backend/ directory ──────────────────────────────
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from honeypots.ssh_honeypot import SSHHoneypot
from honeypots.http_honeypot import HTTPHoneypot
from honeypots.ftp_honeypot import FTPHoneypot
from honeypots.telnet_honeypot import TelnetHoneypot
from core.database import init_db

def print_banner():
    print("""
  ╔══════════════════════════════════════════════════╗
  ║    🍯 HONEYPOT CYBER ATTACK DETECTION SYSTEM     ║
  ║         Starting all services...                 ║
  ╚══════════════════════════════════════════════════╝""")

def start_honeypots():
    """Instantiate and start all honeypot services in daemon threads."""
    honeypots = [
        SSHHoneypot(host="0.0.0.0", port=2222),
        HTTPHoneypot(host="0.0.0.0", port=8080),
        FTPHoneypot(host="0.0.0.0", port=2121),
        TelnetHoneypot(host="0.0.0.0", port=2323),
    ]
    labels = ["SSH :2222", "HTTP :8080", "FTP :2121", "TELNET :2323"]
    for hp, label in zip(honeypots, labels):
        threading.Thread(target=hp.start, daemon=True).start()
        print(f"  [✓] {label} honeypot started")
        time.sleep(0.2)
    return honeypots

def main():
    print_banner()

    # Initialize DB tables
    init_db()
    print("  [✓] Database initialized")

    # Start honeypots
    _honeypots = start_honeypots()

    print("  [✓] Dashboard  → http://localhost:5000")
    print("  [✓] API health → http://localhost:5000/api/health")
    print()

    try:
        uvicorn.run(
            "api.main:app",
            host="0.0.0.0",
            port=5000,
            log_level="info",
            reload=False,
        )
    except KeyboardInterrupt:
        print("\n  [!] Shutting down gracefully...")
        sys.exit(0)

if __name__ == "__main__":
    main()
