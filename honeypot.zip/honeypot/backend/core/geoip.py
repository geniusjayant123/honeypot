import requests
import ipaddress
import logging

logger = logging.getLogger(__name__)

_IP_CACHE = {}

def is_private_ip(ip: str) -> bool:
    try:
        ip_obj = ipaddress.ip_address(ip)
        return ip_obj.is_private or ip_obj.is_loopback or ip_obj.is_unspecified
    except ValueError:
        return True

def resolve_ip(ip: str) -> dict:
    if not ip or is_private_ip(ip):
        return {}
    
    if ip in _IP_CACHE:
        return _IP_CACHE[ip]

    try:
        url = f"http://ip-api.com/json/{ip}?fields=status,message,country,countryCode,regionName,city,lat,lon,as,org"
        response = requests.get(url, timeout=5)
        response.raise_for_status()
        data = response.json()
        if data.get("status") == "success":
            _IP_CACHE[ip] = data
            return data
        return {}
    except Exception as e:
        logger.error(f"Failed to resolve IP {ip}: {e}")
        return {}

def resolve_batch(ips: list) -> dict:
    results = {}
    for ip in ips:
        results[ip] = resolve_ip(ip)
    return results
