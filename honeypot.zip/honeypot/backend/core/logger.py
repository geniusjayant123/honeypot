"""
Structured event logger for the Honeypot system.
Logs events to SQLite DB, a JSON log file, and broadcasts to WebSocket clients.
"""
import asyncio
import json
import logging
import os
from datetime import datetime
from typing import Any, Optional, Set

from sqlalchemy.orm import Session

from core.database import AttackEvent, AttackerProfile, get_session
from core.geoip import resolve_ip
from core.classifier import classify_event, compute_severity

# ── Standard logger ───────────────────────────────────────────────────────────
os.makedirs("logs", exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.FileHandler("logs/honeypot.log"),
        logging.StreamHandler(),
    ],
)
log = logging.getLogger("honeypot.logger")

# ── WebSocket broadcast set ───────────────────────────────────────────────────
# Active WebSocket connections are stored here; api/main.py manages this set.
_ws_clients: Set[Any] = set()


def register_ws_client(ws):
    _ws_clients.add(ws)


def unregister_ws_client(ws):
    _ws_clients.discard(ws)


async def _broadcast(data: dict):
    """Push JSON event to all connected WebSocket clients."""
    if not _ws_clients:
        return
    msg = json.dumps(data)
    dead = set()
    for ws in list(_ws_clients):
        try:
            await ws.send_text(msg)
        except Exception:
            dead.add(ws)
    _ws_clients -= dead


# ── Main logging function ─────────────────────────────────────────────────────

def log_event(
    *,
    source_ip: str,
    source_port: Optional[int] = None,
    destination_port: Optional[int] = None,
    service: str,                          # ssh | http | ftp | telnet
    username: Optional[str] = None,
    password: Optional[str] = None,
    payload: Optional[str] = None,
    command: Optional[str] = None,
    user_agent: Optional[str] = None,
    http_method: Optional[str] = None,
    http_path: Optional[str] = None,
    extra: Optional[dict] = None,
) -> Optional[AttackEvent]:
    """
    Central function called by every honeypot to log an attack event.
    Handles: GeoIP resolution, attack classification, DB persistence, alerting.
    """
    try:
        db: Session = get_session()

        # 1. GeoIP resolution
        geo = resolve_ip(source_ip)

        # 2. Rule-based classification
        attack_type = classify_event(
            db=db,
            source_ip=source_ip,
            service=service,
            username=username,
            password=password,
            payload=payload,
            command=command,
        )
        severity = compute_severity(attack_type)

        # 3. ML classification (lazy import to avoid startup cost)
        ml_attack_type, ml_confidence = None, None
        try:
            from core.ml_detector import predict
            ml_attack_type, ml_confidence = predict(
                service=service,
                attack_type=attack_type,
                username=username,
                password=password,
                payload=payload,
            )
        except Exception:
            pass  # ML module optional

        # 4. Create DB record
        event = AttackEvent(
            timestamp=datetime.utcnow(),
            source_ip=source_ip,
            source_port=source_port,
            destination_port=destination_port,
            service=service,
            attack_type=attack_type,
            severity=severity,
            username=username,
            password=password,
            payload=payload,
            command=command,
            user_agent=user_agent,
            http_method=http_method,
            http_path=http_path,
            country=geo.get("country"),
            country_code=geo.get("countryCode"),
            city=geo.get("city"),
            region=geo.get("regionName"),
            latitude=geo.get("lat"),
            longitude=geo.get("lon"),
            asn=geo.get("as"),
            org=geo.get("org"),
            ml_attack_type=ml_attack_type,
            ml_confidence=ml_confidence,
        )
        db.add(event)
        db.commit()
        db.refresh(event)

        # 5. Update attacker profile
        _update_attacker_profile(db, event)

        # 6. Broadcast to WebSocket clients
        asyncio.get_event_loop().call_soon_threadsafe(
            lambda: asyncio.ensure_future(_broadcast(event.to_dict()))
        )

        # 7. Alert engine (async fire-and-forget)
        try:
            from alerts.alert_engine import maybe_alert
            maybe_alert(event)
        except Exception:
            pass

        # 8. Console log
        log.info(
            f"[{service.upper()}] {source_ip} → {attack_type} "
            f"| severity={severity} | country={geo.get('country', '?')} "
            f"| user={username} pass={password}"
        )

        db.close()
        return event

    except Exception as exc:
        log.error(f"log_event error: {exc}", exc_info=True)
        return None


def _update_attacker_profile(db: Session, event: AttackEvent):
    """Create or update the AttackerProfile for the source IP."""
    profile = db.query(AttackerProfile).filter_by(ip_address=event.source_ip).first()
    if not profile:
        profile = AttackerProfile(
            ip_address=event.source_ip,
            first_seen=event.timestamp,
            country=event.country,
            country_code=event.country_code,
            city=event.city,
            latitude=event.latitude,
            longitude=event.longitude,
            org=event.org,
        )
        db.add(profile)

    profile.last_seen = event.timestamp
    profile.total_attempts = (profile.total_attempts or 0) + 1

    # Update services hit (unique)
    services = set((profile.services_hit or "").split(",")) - {""}
    services.add(event.service)
    profile.services_hit = ",".join(sorted(services))

    # Update attack types
    atypes = set((profile.attack_types or "").split(",")) - {""}
    if event.attack_type:
        atypes.add(event.attack_type)
    profile.attack_types = ",".join(sorted(atypes))

    # Update max severity
    sev_order = {"LOW": 1, "MEDIUM": 2, "HIGH": 3, "CRITICAL": 4}
    cur = sev_order.get(profile.max_severity or "LOW", 1)
    new = sev_order.get(event.severity or "LOW", 1)
    if new > cur:
        profile.max_severity = event.severity

    db.commit()
