import os
import numpy as np
try:
    import joblib
except ImportError:
    joblib = None

MODEL_PATH = 'ml/model.pkl'

def _encode_service(service: str) -> int:
    mapping = {'ssh': 0, 'http': 1, 'ftp': 2, 'telnet': 3}
    return mapping.get(service.lower(), 4)

def extract_features(service: str, username: str, password: str, payload: str) -> np.ndarray:
    svc_enc = _encode_service(service)
    ulen = len(username) if username else 0
    plen = len(password) if password else 0
    paylen = len(payload) if payload else 0
    special_chars = 1 if payload and any(not c.isalnum() and not c.isspace() for c in payload) else 0
    
    return np.array([[svc_enc, plen, ulen, paylen, special_chars]])

def predict(service: str, attack_type: str, username: str, password: str, payload: str) -> tuple[str, float]:
    if joblib and os.path.exists(MODEL_PATH):
        try:
            model = joblib.load(MODEL_PATH)
            features = extract_features(service, username, password, payload)
            pred_label = model.predict(features)[0]
            confidence = float(np.max(model.predict_proba(features)))
            return (str(pred_label), confidence)
        except Exception:
            pass
    
    return (attack_type, 0.9)
