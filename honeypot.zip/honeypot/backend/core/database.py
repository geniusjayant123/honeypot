"""
Database models and connection management for the Honeypot system.
Uses SQLAlchemy ORM with SQLite (dev) / PostgreSQL (prod).
"""
import os
from datetime import datetime
from typing import Optional

from sqlalchemy import (
    Column, Integer, String, Float, DateTime, Text, Boolean, create_engine, event
)
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker
import yaml

# ── Load config ──────────────────────────────────────────────────────────────
_BACKEND_DIR = os.path.dirname(os.path.abspath(__file__))          # backend/core/
_BACKEND_ROOT = os.path.dirname(_BACKEND_DIR)                       # backend/
_PROJECT_ROOT = os.path.dirname(_BACKEND_ROOT)                     # honeypot/

_cfg_path = os.path.join(_BACKEND_ROOT, "config.yaml")
with open(_cfg_path) as f:
    _cfg = yaml.safe_load(f)

_raw_url = _cfg["database"]["url"]

# If using SQLite with a relative path, make it absolute at the project root
if _raw_url.startswith("sqlite:///./") or _raw_url == "sqlite:///honeypot.db":
    _db_filename = _raw_url.replace("sqlite:///./", "").replace("sqlite:///", "")
    _abs_db_path = os.path.join(_PROJECT_ROOT, _db_filename).replace("\\", "/")
    DATABASE_URL = f"sqlite:///{_abs_db_path}"
else:
    DATABASE_URL = _raw_url


# ── SQLAlchemy engine ─────────────────────────────────────────────────────────
engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False} if "sqlite" in DATABASE_URL else {},
    echo=False,
)

# Enable WAL mode for SQLite (better concurrent read performance)
if "sqlite" in DATABASE_URL:
    @event.listens_for(engine, "connect")
    def set_sqlite_pragma(dbapi_conn, _):
        cursor = dbapi_conn.cursor()
        cursor.execute("PRAGMA journal_mode=WAL")
        cursor.execute("PRAGMA synchronous=NORMAL")
        cursor.close()

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


class Base(DeclarativeBase):
    pass


# ── Models ────────────────────────────────────────────────────────────────────

class AttackEvent(Base):
    """
    Represents a single attack/probe event captured by any honeypot.
    """
    __tablename__ = "attack_events"

    id              = Column(Integer, primary_key=True, index=True)
    timestamp       = Column(DateTime, default=datetime.utcnow, index=True)

    # Network info
    source_ip       = Column(String(45), nullable=False, index=True)
    source_port     = Column(Integer, nullable=True)
    destination_port= Column(Integer, nullable=True)

    # Honeypot / service info
    service         = Column(String(20), nullable=False, index=True)   # ssh|http|ftp|telnet
    attack_type     = Column(String(50), nullable=True, index=True)    # brute_force|recon|etc.
    severity        = Column(String(10), nullable=True, index=True)    # LOW|MEDIUM|HIGH|CRITICAL

    # Credential attempts
    username        = Column(String(255), nullable=True)
    password        = Column(String(255), nullable=True)

    # Payload / command data
    payload         = Column(Text, nullable=True)
    command         = Column(Text, nullable=True)
    user_agent      = Column(String(512), nullable=True)
    http_method     = Column(String(10), nullable=True)
    http_path       = Column(String(512), nullable=True)

    # GeoIP
    country         = Column(String(100), nullable=True)
    country_code    = Column(String(5), nullable=True)
    city            = Column(String(100), nullable=True)
    region          = Column(String(100), nullable=True)
    latitude        = Column(Float, nullable=True)
    longitude       = Column(Float, nullable=True)
    asn             = Column(String(50), nullable=True)
    org             = Column(String(255), nullable=True)

    # ML classification
    ml_attack_type  = Column(String(50), nullable=True)
    ml_confidence   = Column(Float, nullable=True)

    # Alert status
    alert_sent      = Column(Boolean, default=False)

    def to_dict(self) -> dict:
        return {
            "id":               self.id,
            "timestamp":        self.timestamp.isoformat() if self.timestamp else None,
            "source_ip":        self.source_ip,
            "source_port":      self.source_port,
            "destination_port": self.destination_port,
            "service":          self.service,
            "attack_type":      self.attack_type,
            "severity":         self.severity,
            "username":         self.username,
            "password":         self.password,
            "payload":          self.payload,
            "command":          self.command,
            "user_agent":       self.user_agent,
            "http_method":      self.http_method,
            "http_path":        self.http_path,
            "country":          self.country,
            "country_code":     self.country_code,
            "city":             self.city,
            "region":           self.region,
            "latitude":         self.latitude,
            "longitude":        self.longitude,
            "asn":              self.asn,
            "org":              self.org,
            "ml_attack_type":   self.ml_attack_type,
            "ml_confidence":    self.ml_confidence,
        }


class AttackerProfile(Base):
    """
    Aggregated profile for each unique attacker IP.
    Updated automatically as new events arrive.
    """
    __tablename__ = "attacker_profiles"

    id              = Column(Integer, primary_key=True, index=True)
    ip_address      = Column(String(45), unique=True, nullable=False, index=True)
    first_seen      = Column(DateTime, default=datetime.utcnow)
    last_seen       = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    total_attempts  = Column(Integer, default=0)
    services_hit    = Column(String(100), nullable=True)  # comma-separated
    max_severity    = Column(String(10), nullable=True)
    attack_types    = Column(String(255), nullable=True)  # comma-separated

    # GeoIP (duplicated for quick lookup)
    country         = Column(String(100), nullable=True)
    country_code    = Column(String(5), nullable=True)
    city            = Column(String(100), nullable=True)
    latitude        = Column(Float, nullable=True)
    longitude       = Column(Float, nullable=True)
    org             = Column(String(255), nullable=True)

    is_blocked      = Column(Boolean, default=False)

    def to_dict(self) -> dict:
        return {
            "id":            self.id,
            "ip_address":    self.ip_address,
            "first_seen":    self.first_seen.isoformat() if self.first_seen else None,
            "last_seen":     self.last_seen.isoformat() if self.last_seen else None,
            "total_attempts":self.total_attempts,
            "services_hit":  self.services_hit.split(",") if self.services_hit else [],
            "max_severity":  self.max_severity,
            "attack_types":  self.attack_types.split(",") if self.attack_types else [],
            "country":       self.country,
            "country_code":  self.country_code,
            "city":          self.city,
            "latitude":      self.latitude,
            "longitude":     self.longitude,
            "org":           self.org,
        }


# ── DB helpers ────────────────────────────────────────────────────────────────

def init_db():
    """Create all tables if they don't exist."""
    Base.metadata.create_all(bind=engine)


def get_db() -> Session:
    """FastAPI dependency: yields a DB session."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def get_session() -> Session:
    """Returns a raw session for use outside FastAPI."""
    return SessionLocal()
