import re
from datetime import datetime, timedelta
try:
    from sqlalchemy.orm import Session
    from core.database import AttackEvent
except ImportError:
    pass

TOP_PASSWORDS = {'admin', 'password', '123456', '123456789', '1234', '12345', 'root', 'test', 'guest', '111111', 'user', '123123', 'qwerty', '12345678', 'system', 'sysadmin', 'administrator', 'toor', 'default'}

def classify_event(db, source_ip: str, service: str, username: str, password: str, payload: str, command: str) -> str:
    # Check command injection
    if command:
        cmd_patterns = [r';', r'\|', r'&&', r'cat /etc', r'/bin/sh', r'wget', r'curl', r'chmod']
        if any(re.search(p, command) for p in cmd_patterns):
            return 'command_injection'
        
        # Check directory traversal in command
        if '../' in command or '/etc/passwd' in command or '/etc/shadow' in command:
            return 'directory_traversal'

    # Check payload for malware delivery or directory traversal
    if payload:
        if '../' in payload or '/etc/passwd' in payload or '/etc/shadow' in payload:
            return 'directory_traversal'
        if 'ELF' in payload or '#!/bin/' in payload or 'powershell' in payload.lower():
            return 'malware_delivery'
        if service == 'ftp' and 'STOR ' in payload:
            return 'malware_delivery'
        # Basic HTTP POST upload indicator
        if service == 'http' and 'POST ' in payload and ('boundary=' in payload or 'application/octet-stream' in payload):
            return 'malware_delivery'

    # Check botnet probe
    if service == 'telnet':
        if username in ['admin', 'root', 'guest', 'support'] and password in ['admin', 'root', 'guest', 'support', '12345', '123456', '']:
            return 'botnet_probe'

    # Check credential stuffing
    if password and password.lower() in TOP_PASSWORDS:
        return 'credential_stuffing'

    # Check brute force & reconnaissance (requires DB)
    if db:
        try:
            one_min_ago = datetime.utcnow() - timedelta(minutes=1)
            recent_attempts = db.query(AttackEvent).filter(
                AttackEvent.source_ip == source_ip,
                AttackEvent.timestamp >= one_min_ago
            ).count()
            if recent_attempts > 3:
                return 'brute_force'
            
            distinct_services = db.query(AttackEvent.service).filter(
                AttackEvent.source_ip == source_ip,
                AttackEvent.timestamp >= one_min_ago
            ).distinct().count()
            if distinct_services >= 3:
                return 'reconnaissance'
        except Exception:
            pass

    return 'unknown'

def compute_severity(attack_type: str) -> str:
    severity_map = {
        'brute_force': 'HIGH',
        'credential_stuffing': 'MEDIUM',
        'malware_delivery': 'CRITICAL',
        'botnet_probe': 'HIGH',
        'command_injection': 'CRITICAL',
        'directory_traversal': 'HIGH',
        'reconnaissance': 'MEDIUM',
        'unknown': 'LOW'
    }
    return severity_map.get(attack_type, 'LOW')
