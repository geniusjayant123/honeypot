from pydantic import BaseModel, ConfigDict
from typing import List, Optional
from datetime import datetime

class AttackEventSchema(BaseModel):
    id: int
    timestamp: datetime
    source_ip: str
    source_port: Optional[int] = None
    destination_port: Optional[int] = None
    service: str
    attack_type: str
    severity: str
    username: Optional[str] = None
    password: Optional[str] = None
    payload: Optional[str] = None
    command: Optional[str] = None
    user_agent: Optional[str] = None
    http_method: Optional[str] = None
    http_path: Optional[str] = None
    country: Optional[str] = None
    country_code: Optional[str] = None
    city: Optional[str] = None
    region: Optional[str] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    asn: Optional[str] = None
    org: Optional[str] = None
    ml_attack_type: Optional[str] = None
    ml_confidence: Optional[float] = None
    alert_sent: bool = False

    model_config = ConfigDict(from_attributes=True)

class AttackerProfileSchema(BaseModel):
    id: int
    ip_address: str
    first_seen: Optional[datetime] = None
    last_seen: Optional[datetime] = None
    total_attempts: int = 0
    services_hit: Optional[str] = None
    max_severity: Optional[str] = None
    attack_types: Optional[str] = None
    country: Optional[str] = None
    country_code: Optional[str] = None
    city: Optional[str] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    org: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)

class PaginatedEventsResponse(BaseModel):
    total: int
    page: int
    per_page: int
    items: List[AttackEventSchema]

class SummaryStats(BaseModel):
    total_events: int
    unique_ips: int
    unique_countries: int
    top_service: Optional[str] = None
    top_attack_type: Optional[str] = None
    top_country: Optional[str] = None
    events_last_24h: int
    events_last_hour: int

class TimelinePoint(BaseModel):
    timestamp: str
    count: int

class BreakdownItem(BaseModel):
    label: str
    count: int
    percentage: float
