from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from sqlalchemy import func
from datetime import datetime, timedelta
from typing import List
from core.database import AttackEvent, get_db
from api.schemas import SummaryStats, TimelinePoint, BreakdownItem

router = APIRouter(prefix='/api/stats', tags=['stats'])

@router.get('/summary', response_model=SummaryStats)
def get_summary(db: Session = Depends(get_db)):
    total = db.query(func.count(AttackEvent.id)).scalar() or 0
    unique_ips = db.query(func.count(func.distinct(AttackEvent.source_ip))).scalar() or 0
    unique_countries = db.query(func.count(func.distinct(AttackEvent.country))).scalar() or 0
    
    top_service = db.query(AttackEvent.service, func.count(AttackEvent.id).label('c')).group_by(AttackEvent.service).order_by(func.count(AttackEvent.id).desc()).first()
    top_attack = db.query(AttackEvent.attack_type, func.count(AttackEvent.id).label('c')).group_by(AttackEvent.attack_type).order_by(func.count(AttackEvent.id).desc()).first()
    top_country = db.query(AttackEvent.country, func.count(AttackEvent.id).label('c')).filter(AttackEvent.country != None).group_by(AttackEvent.country).order_by(func.count(AttackEvent.id).desc()).first()
    
    last_24h = datetime.utcnow() - timedelta(hours=24)
    last_1h = datetime.utcnow() - timedelta(hours=1)
    
    events_24h = db.query(func.count(AttackEvent.id)).filter(AttackEvent.timestamp >= last_24h).scalar() or 0
    events_1h = db.query(func.count(AttackEvent.id)).filter(AttackEvent.timestamp >= last_1h).scalar() or 0
    
    return {
        "total_events": total,
        "unique_ips": unique_ips,
        "unique_countries": unique_countries,
        "top_service": top_service[0] if top_service else None,
        "top_attack_type": top_attack[0] if top_attack else None,
        "top_country": top_country[0] if top_country else None,
        "events_last_24h": events_24h,
        "events_last_hour": events_1h
    }

@router.get('/timeline', response_model=List[TimelinePoint])
def get_timeline(hours: int = Query(24, ge=1, le=720), db: Session = Depends(get_db)):
    since = datetime.utcnow() - timedelta(hours=hours)
    
    # SQLite friendly grouping by hour
    results = db.query(
        func.strftime('%Y-%m-%d %H:00:00', AttackEvent.timestamp).label('hour'),
        func.count(AttackEvent.id)
    ).filter(AttackEvent.timestamp >= since).group_by('hour').order_by('hour').all()
    
    return [{"timestamp": r[0], "count": r[1]} for r in results]

def get_breakdown(field, db: Session):
    total = db.query(func.count(AttackEvent.id)).scalar() or 1 # avoid div by zero
    results = db.query(field, func.count(AttackEvent.id)).filter(field != None).group_by(field).order_by(func.count(AttackEvent.id).desc()).all()
    return [{"label": str(r[0]), "count": r[1], "percentage": round((r[1] / total) * 100, 2)} for r in results]

@router.get('/by-type', response_model=List[BreakdownItem])
def get_by_type(db: Session = Depends(get_db)):
    return get_breakdown(AttackEvent.attack_type, db)

@router.get('/by-service', response_model=List[BreakdownItem])
def get_by_service(db: Session = Depends(get_db)):
    return get_breakdown(AttackEvent.service, db)

@router.get('/by-severity', response_model=List[BreakdownItem])
def get_by_severity(db: Session = Depends(get_db)):
    return get_breakdown(AttackEvent.severity, db)

@router.get('/by-country', response_model=List[BreakdownItem])
def get_by_country(db: Session = Depends(get_db)):
    items = get_breakdown(AttackEvent.country, db)
    return items[:10]
