from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import Optional
from core.database import AttackEvent, get_db
from api.schemas import PaginatedEventsResponse, AttackEventSchema

router = APIRouter(prefix='/api/events', tags=['events'])

@router.get('/', response_model=PaginatedEventsResponse)
def get_events(
    page: int = Query(1, ge=1),
    per_page: int = Query(20, ge=1, le=100),
    service: Optional[str] = None,
    severity: Optional[str] = None,
    attack_type: Optional[str] = None,
    db: Session = Depends(get_db)
):
    query = db.query(AttackEvent)
    
    if service:
        query = query.filter(AttackEvent.service == service)
    if severity:
        query = query.filter(AttackEvent.severity == severity)
    if attack_type:
        query = query.filter(AttackEvent.attack_type == attack_type)
        
    total = query.count()
    items = query.order_by(AttackEvent.timestamp.desc()).offset((page - 1) * per_page).limit(per_page).all()
    
    return {
        "total": total,
        "page": page,
        "per_page": per_page,
        "items": [item.to_dict() for item in items]
    }

@router.get('/{event_id}', response_model=AttackEventSchema)
def get_event(event_id: int, db: Session = Depends(get_db)):
    event = db.query(AttackEvent).filter(AttackEvent.id == event_id).first()
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")
    return event.to_dict()

@router.delete('/clear')
def clear_events(db: Session = Depends(get_db)):
    db.query(AttackEvent).delete()
    db.commit()
    return {"message": "All events cleared"}
