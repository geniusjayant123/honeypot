from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List
from core.database import AttackerProfile, AttackEvent, get_db
from api.schemas import AttackerProfileSchema

router = APIRouter(prefix='/api/attackers', tags=['attackers'])

@router.get('/', response_model=List[AttackerProfileSchema])
def get_attackers(limit: int = Query(50, ge=1, le=1000), db: Session = Depends(get_db)):
    attackers = db.query(AttackerProfile).order_by(AttackerProfile.total_attempts.desc()).limit(limit).all()
    return attackers

@router.get('/{ip}')
def get_attacker_profile(ip: str, db: Session = Depends(get_db)):
    profile = db.query(AttackerProfile).filter(AttackerProfile.ip_address == ip).first()
    if not profile:
        raise HTTPException(status_code=404, detail="Attacker not found")
        
    recent_events = db.query(AttackEvent).filter(AttackEvent.source_ip == ip).order_by(AttackEvent.timestamp.desc()).limit(20).all()
    
    return {
        "profile": profile,
        "recent_events": [e.to_dict() for e in recent_events]
    }
