from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from datetime import datetime
import asyncio
import os

from api.routes import events, stats, attackers
from core.database import init_db
try:
    from core.logger import register_ws_client, unregister_ws_client
except ImportError:
    # Dummy handlers in case core.logger doesn't have them
    def register_ws_client(ws): pass
    def unregister_ws_client(ws): pass

app = FastAPI(title='Honeypot Detection System', version='1.0.0')

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(events.router)
app.include_router(stats.router)
app.include_router(attackers.router)

frontend_path = os.path.join(os.path.dirname(__file__), '..', '..', 'frontend')
if os.path.exists(frontend_path):
    app.mount("/static", StaticFiles(directory=frontend_path), name="static")

@app.on_event("startup")
def on_startup():
    init_db()

@app.get('/api/health')
def health_check():
    return {"status": "ok", "timestamp": datetime.utcnow().isoformat()}

@app.websocket('/ws/live')
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    register_ws_client(websocket)
    try:
        while True:
            await asyncio.sleep(1)
    except WebSocketDisconnect:
        unregister_ws_client(websocket)
    except Exception:
        unregister_ws_client(websocket)

@app.get('/')
def serve_index():
    index_path = os.path.join(frontend_path, 'index.html')
    if os.path.exists(index_path):
        return FileResponse(index_path)
    return {"message": "Frontend not found, but API is running"}
