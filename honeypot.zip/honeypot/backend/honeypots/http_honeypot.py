from flask import Flask, request
import threading
import logging
try:
    from core.logger import log_event
except ImportError:
    def log_event(**kwargs): pass

app = Flask(__name__)

log = logging.getLogger('werkzeug')
log.setLevel(logging.ERROR)

@app.before_request
def log_request():
    payload = request.get_data(as_text=True)
    username = request.form.get('username') or request.form.get('log') or ''
    password = request.form.get('password') or request.form.get('pwd') or ''
    log_event(
        service='http',
        source_ip=request.remote_addr,
        http_method=request.method,
        http_path=request.path,
        user_agent=request.headers.get('User-Agent'),
        payload=payload,
        username=username,
        password=password
    )

@app.route('/', methods=['GET'])
def index():
    return "<html><body><h1>Index of /</h1><ul><li><a href='admin/'>admin/</a></li><li><a href='wp-login.php'>wp-login.php</a></li></ul></body></html>"

@app.route('/wp-login.php', methods=['GET', 'POST'])
def wp_login():
    return "<html><body><h2>WordPress Login</h2><form method='POST'><input name='log' placeholder='Username'/><input name='pwd' type='password' placeholder='Password'/><input type='submit'/></form></body></html>"

@app.route('/admin', methods=['GET', 'POST'])
def admin_panel():
    return "<html><body><h2>Admin Panel</h2><form method='POST'><input name='username' placeholder='Admin'/><input name='password' type='password'/><input type='submit'/></form></body></html>"

@app.route('/login', methods=['GET', 'POST'])
def login():
    return "<html><body><h2>Login</h2><form method='POST'><input name='username'/><input name='password' type='password'/><input type='submit'/></form></body></html>"

@app.route('/phpmyadmin', methods=['GET'])
def phpmyadmin():
    return "<html><body><h2>phpMyAdmin</h2><form method='POST'><input name='pma_username'/><input name='pma_password' type='password'/><input type='submit'/></form></body></html>"

@app.route('/.env', methods=['GET'])
def env_file():
    return "DB_HOST=127.0.0.1\nDB_USER=root\nDB_PASS=secret123\nAWS_ACCESS_KEY_ID=AKIAIOSFODNN7EXAMPLE\n"

@app.route('/etc/passwd', methods=['GET'])
@app.route('/../../../etc/passwd', methods=['GET'])
def dir_traversal():
    return "Forbidden", 403

@app.errorhandler(404)
def page_not_found(e):
    return "404 Not Found", 404

class HTTPHoneypot:
    def __init__(self, host='0.0.0.0', port=8080):
        self.host = host
        self.port = port
        self.server_thread = None

    def start(self):
        self.server_thread = threading.Thread(
            target=lambda: app.run(host=self.host, port=self.port, debug=False, use_reloader=False),
            daemon=True
        )
        self.server_thread.start()

    def stop(self):
        pass
