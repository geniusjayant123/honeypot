import asyncio
import logging
try:
    from core.logger import log_event
except ImportError:
    def log_event(**kwargs): pass

logger = logging.getLogger(__name__)

class TelnetHoneypot:
    def __init__(self, host='0.0.0.0', port=2323):
        self.host = host
        self.port = port
        self.server = None
        self.loop = None
        self.thread = None
        self.banner = (
            "BusyBox v1.29.3 (2019-01-24 15:12:37 CET) built-in shell (ash)\n"
            "Enter 'help' for a list of built-in commands\n\n"
            "router login: "
        )

    async def handle_client(self, reader, writer):
        addr = writer.get_extra_info('peername')
        client_ip = addr[0] if addr else 'Unknown'
        
        log_event(service='telnet', source_ip=client_ip)

        try:
            writer.write(self.banner.encode('utf-8'))
            await writer.drain()

            username_data = await reader.readline()
            username = username_data.decode('utf-8', errors='ignore').strip()

            writer.write(b"Password: ")
            await writer.drain()

            password_data = await reader.readline()
            password = password_data.decode('utf-8', errors='ignore').strip()

            log_event(service='telnet', source_ip=client_ip, username=username, password=password)

            writer.write(b"\r\n~ # ")
            await writer.drain()

            while True:
                cmd_data = await reader.readline()
                if not cmd_data:
                    break
                
                cmd = cmd_data.decode('utf-8', errors='ignore').strip()
                if cmd == 'exit' or cmd == 'quit':
                    break
                elif cmd:
                    log_event(service='telnet', source_ip=client_ip, command=cmd)
                    writer.write(f"ash: {cmd}: not found\r\n".encode('utf-8'))
                
                writer.write(b"~ # ")
                await writer.drain()

        except Exception as e:
            logger.error(f"Telnet connection error: {e}")
        finally:
            writer.close()

    async def _start_server(self):
        self.server = await asyncio.start_server(
            self.handle_client, self.host, self.port
        )
        async with self.server:
            await self.server.serve_forever()

    def start(self):
        def run_loop():
            self.loop = asyncio.new_event_loop()
            asyncio.set_event_loop(self.loop)
            self.loop.run_until_complete(self._start_server())

        import threading
        self.thread = threading.Thread(target=run_loop, daemon=True)
        self.thread.start()

    def stop(self):
        if self.loop and self.loop.is_running():
            self.loop.call_soon_threadsafe(self.server.close)
            self.loop.call_soon_threadsafe(self.loop.stop)
