import asyncio
import logging
try:
    from core.logger import log_event
except ImportError:
    def log_event(**kwargs): pass

logger = logging.getLogger(__name__)

class FTPHoneypot:
    def __init__(self, host='0.0.0.0', port=2121):
        self.host = host
        self.port = port
        self.server = None
        self.loop = None
        self.thread = None

    async def handle_client(self, reader, writer):
        addr = writer.get_extra_info('peername')
        client_ip = addr[0] if addr else 'Unknown'
        
        writer.write(b"220 (vsFTPd 3.0.3)\r\n")
        await writer.drain()
        
        username = ""
        password = ""
        
        log_event(service='ftp', source_ip=client_ip)

        try:
            while True:
                data = await reader.readline()
                if not data:
                    break
                
                cmd_line = data.decode('utf-8').strip()
                parts = cmd_line.split(' ', 1)
                cmd = parts[0].upper()
                arg = parts[1] if len(parts) > 1 else ""
                
                if cmd == 'USER':
                    username = arg
                    writer.write(b"331 Please specify the password.\r\n")
                elif cmd == 'PASS':
                    password = arg
                    log_event(service='ftp', source_ip=client_ip, username=username, password=password)
                    writer.write(b"230 Login successful.\r\n")
                elif cmd == 'SYST':
                    writer.write(b"215 UNIX Type: L8\r\n")
                elif cmd == 'PWD':
                    writer.write(b"257 \"/\" is the current directory\r\n")
                elif cmd == 'TYPE':
                    writer.write(b"200 Switching to Binary mode.\r\n")
                elif cmd == 'PASV':
                    writer.write(b"227 Entering Passive Mode (127,0,0,1,195,149).\r\n")
                elif cmd == 'PORT':
                    writer.write(b"200 PORT command successful.\r\n")
                elif cmd == 'LIST':
                    writer.write(b"150 Here comes the directory listing.\r\n")
                    await writer.drain()
                    writer.write(b"226 Directory send OK.\r\n")
                elif cmd == 'STOR':
                    log_event(service='ftp', source_ip=client_ip, payload=cmd_line)
                    writer.write(b"150 Ok to send data.\r\n")
                    await writer.drain()
                    writer.write(b"226 Transfer complete.\r\n")
                elif cmd == 'RETR':
                    writer.write(b"550 Failed to open file.\r\n")
                elif cmd == 'QUIT':
                    writer.write(b"221 Goodbye.\r\n")
                    await writer.drain()
                    break
                else:
                    writer.write(b"500 Unknown command.\r\n")
                    
                await writer.drain()
        except Exception as e:
            logger.error(f"FTP connection error: {e}")
        finally:
            writer.close()

    async def _start_server(self):
        self.server = await asyncio.start_server(
            self.handle_client, self.host, self.port
        )
        async with self.server:
            await self.server.serve_forever()

    def start(self):
        def run_loop():
            self.loop = asyncio.new_event_loop()
            asyncio.set_event_loop(self.loop)
            self.loop.run_until_complete(self._start_server())

        import threading
        self.thread = threading.Thread(target=run_loop, daemon=True)
        self.thread.start()

    def stop(self):
        if self.loop and self.loop.is_running():
            self.loop.call_soon_threadsafe(self.server.close)
            self.loop.call_soon_threadsafe(self.loop.stop)
