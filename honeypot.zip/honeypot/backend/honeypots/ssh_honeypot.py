import paramiko
import threading
import socket
import logging
import os
import yaml

try:
    from core.logger import log_event
except ImportError:
    def log_event(**kwargs): pass

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

HOST_KEY_PATH = 'ssh_host_rsa_key'

if not os.path.exists(HOST_KEY_PATH):
    logger.info(f"Generating new RSA key at {HOST_KEY_PATH}")
    key = paramiko.RSAKey.generate(2048)
    key.write_private_key_file(HOST_KEY_PATH)

class FakeSSHServer(paramiko.ServerInterface):
    def __init__(self):
        self.event = threading.Event()
        
    def check_auth_password(self, username, password):
        log_event(service='ssh', username=username, password=password)
        return paramiko.AUTH_SUCCESSFUL
        
    def check_auth_publickey(self, username, key):
        return paramiko.AUTH_SUCCESSFUL
        
    def check_channel_request(self, kind, chanid):
        if kind == 'session':
            return paramiko.OPEN_SUCCEEDED
        return paramiko.OPEN_FAILED_ADMINISTRATIVELY_PROHIBITED
        
    def check_channel_pty_request(self, channel, term, width, height, pixelwidth, pixelheight, modes):
        return True
        
    def check_channel_shell_request(self, channel):
        self.event.set()
        return True

class SSHHoneypot:
    def __init__(self, host='0.0.0.0', port=2222, config_path=None):
        self.host = host
        self.port = port
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.running = False
        self.config = {}
        if config_path and os.path.exists(config_path):
            try:
                with open(config_path, 'r') as f:
                    self.config = yaml.safe_load(f)
            except Exception:
                pass

    def start(self):
        self.sock.bind((self.host, self.port))
        self.sock.listen(100)
        self.running = True
        logger.info(f"SSH Honeypot listening on {self.host}:{self.port}")
        
        self.thread = threading.Thread(target=self._accept_connections, daemon=True)
        self.thread.start()

    def stop(self):
        self.running = False
        self.sock.close()

    def _accept_connections(self):
        while self.running:
            try:
                client, addr = self.sock.accept()
                t = threading.Thread(target=self._handle_connection, args=(client, addr), daemon=True)
                t.start()
            except Exception as e:
                if self.running:
                    logger.error(f"Error accepting connection: {e}")

    def _handle_connection(self, client, addr):
        try:
            transport = paramiko.Transport(client)
            transport.add_server_key(paramiko.RSAKey(filename=HOST_KEY_PATH))
            server = FakeSSHServer()
            try:
                transport.start_server(server=server)
            except paramiko.SSHException:
                return

            channel = transport.accept(20)
            if channel is None:
                return
            
            server.event.wait(10)
            if not server.event.is_set():
                channel.close()
                return

            channel.send("Last login: Mon Sep 23 08:14:22 2026 from 10.0.0.1\r\n")
            
            while True:
                channel.send("ubuntu@server:~$ ")
                command = ""
                while True:
                    char = channel.recv(1024).decode('utf-8')
                    if not char:
                        break
                    if char == '\r' or char == '\n':
                        channel.send("\r\n")
                        break
                    elif char == '\x03': 
                        command = ""
                        channel.send("^C\r\n")
                        break
                    else:
                        command += char
                        channel.send(char)
                
                if not command:
                    continue
                
                cmd = command.strip()
                log_event(service='ssh', source_ip=addr[0], command=cmd)
                
                if cmd == 'ls':
                    channel.send("Desktop  Documents  .bash_history\r\n")
                elif cmd == 'whoami':
                    channel.send("root\r\n")
                elif cmd == 'uname -a':
                    channel.send("Linux server 5.15.0-76-generic #83-Ubuntu\r\n")
                elif cmd == 'id':
                    channel.send("uid=0(root) gid=0(root)\r\n")
                elif cmd.startswith('cat /etc/passwd'):
                    channel.send("root:x:0:0:root:/root:/bin/bash\r\nwww-data:x:33:33:www-data:/var/www:/usr/sbin/nologin\r\n")
                elif cmd == 'exit':
                    break
                else:
                    channel.send(f"bash: {cmd}: command not found\r\n")
                    
        except Exception as e:
            pass
        finally:
            client.close()
