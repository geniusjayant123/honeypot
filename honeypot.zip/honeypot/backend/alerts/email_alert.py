import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import logging

logger = logging.getLogger(__name__)

def send_email_alert(event_dict: dict, config: dict):
    try:
        smtp_config = config.get("email", {})
        if not smtp_config.get("enabled"):
            return
        
        sender = smtp_config.get("sender_email")
        password = smtp_config.get("sender_password")
        receiver = smtp_config.get("receiver_email")
        smtp_server = smtp_config.get("smtp_server", "smtp.gmail.com")
        smtp_port = smtp_config.get("smtp_port", 587)
        
        msg = MIMEMultipart("alternative")
        msg["Subject"] = f"🚨 Honeypot Alert: {event_dict.get('severity', 'UNKNOWN')} Severity Attack"
        msg["From"] = sender
        msg["To"] = receiver
        
        html = f"""
        <html>
          <body>
            <h2>Honeypot Attack Alert</h2>
            <p><strong>IP:</strong> {event_dict.get('source_ip')}</p>
            <p><strong>Country:</strong> {event_dict.get('country')}</p>
            <p><strong>Service:</strong> {event_dict.get('service')}</p>
            <p><strong>Attack Type:</strong> {event_dict.get('attack_type')}</p>
            <p><strong>Severity:</strong> {event_dict.get('severity')}</p>
            <p><strong>Timestamp:</strong> {event_dict.get('timestamp')}</p>
            <p><strong>Payload:</strong> {event_dict.get('payload') or event_dict.get('command') or 'N/A'}</p>
          </body>
        </html>
        """
        part = MIMEText(html, "html")
        msg.attach(part)
        
        with smtplib.SMTP(smtp_server, smtp_port) as server:
            server.starttls()
            server.login(sender, password)
            server.sendmail(sender, receiver, msg.as_string())
            
        logger.info(f"Email alert sent for event from IP {event_dict.get('source_ip')}")
    except Exception as e:
        logger.error(f"Failed to send email alert: {e}")
