import requests
import logging

logger = logging.getLogger(__name__)

def send_telegram_alert(event_dict: dict, config: dict):
    try:
        tg_config = config.get("telegram", {})
        if not tg_config.get("enabled"):
            return
        
        bot_token = tg_config.get("bot_token")
        chat_id = tg_config.get("chat_id")
        
        if not bot_token or not chat_id:
            logger.error("Telegram bot_token or chat_id missing in config")
            return
            
        message = (
            f"🚨 ATTACK ALERT\n"
            f"🌐 IP: {event_dict.get('source_ip')}\n"
            f"🏳️ Country: {event_dict.get('country')}\n"
            f"⚔️ Type: {event_dict.get('attack_type')}\n"
            f"🎯 Service: {event_dict.get('service')}\n"
            f"⚠️ Severity: {event_dict.get('severity')}"
        )
        
        url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
        payload = {
            "chat_id": chat_id,
            "text": message
        }
        
        response = requests.post(url, json=payload, timeout=10)
        response.raise_for_status()
        logger.info(f"Telegram alert sent for event from IP {event_dict.get('source_ip')}")
    except Exception as e:
        logger.error(f"Failed to send telegram alert: {e}")
