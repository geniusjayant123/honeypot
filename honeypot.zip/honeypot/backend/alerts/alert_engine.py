import yaml
import logging
import threading
from datetime import datetime, timedelta
from typing import Dict
import os
from alerts.email_alert import send_email_alert
from alerts.telegram_alert import send_telegram_alert
from core.database import SessionLocal

logger = logging.getLogger(__name__)

_alert_cooldown: Dict[str, datetime] = {}
_config = {}

SEVERITY_LEVELS = {
    "LOW": 1,
    "MEDIUM": 2,
    "HIGH": 3,
    "CRITICAL": 4
}

def load_config():
    global _config
    config_path = os.path.join(os.path.dirname(__file__), '..', 'config.yaml')
    try:
        if os.path.exists(config_path):
            with open(config_path, 'r') as f:
                _config = yaml.safe_load(f) or {}
    except Exception as e:
        logger.error(f"Failed to load config: {e}")
        _config = {}

load_config()

def _process_alert(event):
    alerts_config = _config.get("alerts", {})
    if not alerts_config.get("enabled", False):
        return

    min_severity = alerts_config.get("min_severity", "HIGH")
    event_severity_val = SEVERITY_LEVELS.get(event.severity, 0)
    min_severity_val = SEVERITY_LEVELS.get(min_severity, 3)

    if event_severity_val < min_severity_val:
        return

    cooldown_minutes = alerts_config.get("cooldown_minutes", 60)
    last_alert_time = _alert_cooldown.get(event.source_ip)
    
    if last_alert_time and datetime.now() - last_alert_time < timedelta(minutes=cooldown_minutes):
        return

    _alert_cooldown[event.source_ip] = datetime.now()
    event_dict = event.to_dict()

    if alerts_config.get("email", {}).get("enabled"):
        send_email_alert(event_dict, alerts_config)
        
    if alerts_config.get("telegram", {}).get("enabled"):
        send_telegram_alert(event_dict, alerts_config)
        
    try:
        db = SessionLocal()
        # Fetch the event to update the alert_sent flag in the new session
        db_event = db.merge(event)
        db_event.alert_sent = True
        db.commit()
    except Exception as e:
        logger.error(f"Failed to update alert_sent flag: {e}")
    finally:
        db.close()

def maybe_alert(event):
    threading.Thread(target=_process_alert, args=(event,), daemon=True).start()
