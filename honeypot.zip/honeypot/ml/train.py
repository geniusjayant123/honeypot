import os
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import joblib

DATA_FILE = os.path.join(os.path.dirname(__file__), 'training_data.csv')
MODEL_FILE = os.path.join(os.path.dirname(__file__), 'model.pkl')

def train_model():
    if not os.path.exists(DATA_FILE):
        print(f"Data file not found at {DATA_FILE}. Please run generate_dataset.py first.")
        return

    print("Loading dataset...")
    df = pd.read_csv(DATA_FILE)
    
    # Features and labels
    X = df.drop('label', axis=1)
    y = df['label']
    
    # Split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    print("Training RandomForestClassifier...")
    clf = RandomForestClassifier(n_estimators=100, max_depth=10, random_state=42)
    clf.fit(X_train, y_train)
    
    # Evaluate
    print("Evaluating model...")
    y_pred = clf.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    
    print(f"\nModel trained successfully! Accuracy: {acc:.2%}\n")
    
    print("Classification Report:")
    print(classification_report(y_test, y_pred))
    
    print("Confusion Matrix:")
    labels = clf.classes_
    cm = confusion_matrix(y_test, y_pred, labels=labels)
    
    # Simple print of confusion matrix with labels
    header = "True \ Pred | " + " | ".join([str(l)[:5] for l in labels])
    print("-" * len(header))
    print(header)
    print("-" * len(header))
    for i, row in enumerate(cm):
        row_str = " | ".join([f"{v:5d}" for v in row])
        print(f"{str(labels[i])[:11]:11s} | {row_str}")
    
    # Save model
    joblib.dump(clf, MODEL_FILE)
    print(f"\nModel saved to {MODEL_FILE}")

if __name__ == '__main__':
    train_model()
