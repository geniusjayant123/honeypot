import csv
import random
import os
from collections import Counter

# Configuration
NUM_ROWS = 5000
OUTPUT_FILE = os.path.join(os.path.dirname(__file__), 'training_data.csv')

# Service mapping
SERVICES = {0: 'ssh', 1: 'http', 2: 'ftp', 3: 'telnet'}

# Attack types and their distribution weights
ATTACK_TYPES = [
    ('brute_force', 40),
    ('reconnaissance', 20),
    ('credential_stuffing', 15),
    ('botnet_probe', 10),
    ('malware_delivery', 10),
    ('unknown', 5)
]

def generate_row():
    # Select attack type based on weights
    attack_type = random.choices([x[0] for x in ATTACK_TYPES], weights=[x[1] for x in ATTACK_TYPES])[0]
    
    # Defaults
    service_id = random.choice([0, 1, 2, 3])
    username_length = random.randint(4, 12)
    password_length = random.randint(6, 16)
    has_common_password = random.choices([0, 1], weights=[80, 20])[0]
    payload_length = random.randint(0, 100)
    has_special_chars = random.choices([0, 1], weights=[50, 50])[0]
    attempts_per_minute = round(random.uniform(0.1, 5.0), 2)
    hour_of_day = random.randint(0, 23)

    # Adjust features based on attack type to make the dataset learnable
    if attack_type == 'brute_force':
        service_id = random.choice([0, 2]) # SSH, FTP
        attempts_per_minute = round(random.uniform(30.0, 120.0), 2)
        has_common_password = 1
        username_length = random.randint(4, 8)
        
    elif attack_type == 'credential_stuffing':
        service_id = 1 # HTTP usually
        attempts_per_minute = round(random.uniform(5.0, 30.0), 2)
        has_common_password = 1
        
    elif attack_type == 'reconnaissance':
        payload_length = random.randint(0, 20)
        attempts_per_minute = round(random.uniform(0.1, 2.0), 2)
        has_special_chars = 0
        
    elif attack_type == 'botnet_probe':
        service_id = 3 # Telnet
        username_length = random.randint(4, 6) # root, admin
        password_length = random.randint(4, 8)
        attempts_per_minute = round(random.uniform(1.0, 10.0), 2)
        has_common_password = 1
        
    elif attack_type == 'malware_delivery':
        payload_length = random.randint(1000, 5000)
        has_special_chars = 1
        attempts_per_minute = round(random.uniform(0.1, 1.0), 2)

    return [
        service_id,
        username_length,
        password_length,
        has_common_password,
        payload_length,
        has_special_chars,
        attempts_per_minute,
        hour_of_day,
        attack_type
    ]

def main():
    os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)
    
    headers = [
        'service_id', 'username_length', 'password_length', 
        'has_common_password', 'payload_length', 'has_special_chars', 
        'attempts_per_minute', 'hour_of_day', 'label'
    ]
    
    data = [generate_row() for _ in range(NUM_ROWS)]
    
    with open(OUTPUT_FILE, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(headers)
        writer.writerows(data)
        
    print(f"Generated {NUM_ROWS} synthetic attack records.")
    print(f"Saved to {OUTPUT_FILE}")
    
    print("\nClass Distribution:")
    labels = [row[-1] for row in data]
    for label, count in Counter(labels).items():
        print(f"  {label}: {count} ({count/NUM_ROWS:.1%})")

if __name__ == '__main__':
    main()
