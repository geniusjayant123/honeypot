@echo off
chcp 65001 > nul
title HoneyShield - Live Attack Simulator
color 0C

SET PYTHON=C:\Users\geniu\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe
SET ROOT=%~dp0

echo.
echo  ╔══════════════════════════════════════════════════╗
echo  ║       🔴 LIVE ATTACK SIMULATOR STARTING          ║
echo  ║   Watch your dashboard fill with real attacks!   ║
echo  ╚══════════════════════════════════════════════════╝
echo.
echo  Make sure the main system (start.bat) is running first!
echo  Dashboard: http://localhost:5000
echo.
echo  Press Ctrl+C to stop simulation.
echo.

"%PYTHON%" -X utf8 "%ROOT%demo_simulation.py"
pause
