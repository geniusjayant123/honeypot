@echo off
chcp 65001 > nul
title HoneyShield - Cyber Attack Detection System
color 0A

echo.
echo  ╔══════════════════════════════════════════════════╗
echo  ║    🍯 HONEYPOT CYBER ATTACK DETECTION SYSTEM     ║
echo  ║              Starting up...                      ║
echo  ╚══════════════════════════════════════════════════╝
echo.

SET PYTHON=C:\Users\geniu\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe
SET ROOT=%~dp0

:: Check if honeypot.db exists, if not run demo first
IF NOT EXIST "%ROOT%honeypot.db" (
    echo  [*] No database found. Running quick demo setup...
    "%PYTHON%" -X utf8 "%ROOT%demo_simulation.py" --count 50 --fast
    echo  [+] Demo data loaded!
    echo.
)

:: Start the main system
echo  [*] Starting HoneyShield system...
echo  [+] Dashboard will open at: http://localhost:5000
echo.
start "" http://localhost:5000
"%PYTHON%" -X utf8 -m uvicorn api.main:app --host 0.0.0.0 --port 5000 --log-level info

pause
